"""
01_prepare_data.py

PURPOSE:
    Load the ROW and TIGER GeoPackages, confirm required columns exist,
    and print CRS information for confirmation. No reprojection, no disk
    outputs, no geometry validation.

INPUTS:
    - ROW_GPKG   : Path to ROW GeoPackage
    - TIGER_GPKG : Path to TIGER GeoPackage (pre-filtered primary/secondary roads)

OUTPUTS:
    - row   : GeoDataFrame saved to namespace for downstream scripts
    - tiger : GeoDataFrame saved to namespace for downstream scripts

NOTES:
    - CRS is assumed to be EPSG:5070. Printed for confirmation only.
    - TIGER is assumed to already contain only primary and secondary roads.
    - Run this script first before any other pipeline script.
"""

import os
import sys
import geopandas as gpd
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from logger_config import get_logger

# ── USER CONFIGURATION ────────────────────────────────────────────────────────
ROW_GPKG   = r"C:\Users\KyleSteen.AzureAD\Documents\Cluster_Analysis\Workspace\CONUS\Level_1_Analysis_CONUS_no_clustering.gpkg"      # <-- UPDATE THIS PATH
TIGER_GPKG = r"C:\Users\KyleSteen.AzureAD\Documents\Cluster_Analysis\Workspace\CONUS\TIGER_CONUS.gpkg"    # <-- UPDATE THIS PATH

ROW_REQUIRED_COLS = ["ROW_ID", "Square_Meters", "State_Name"]
# ─────────────────────────────────────────────────────────────────────────────

logger     = get_logger("01_prepare_data")
start_time = datetime.now()

logger.info("=" * 60)
logger.info("SCRIPT 01 - PREPARE DATA")
logger.info(f"Started : {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
logger.info("=" * 60)

# ── LOAD ROW ──────────────────────────────────────────────────────────────────
logger.info("=" * 60)
logger.info("LOADING ROW GEOPACKAGE")
logger.info("=" * 60)
logger.info(f"File path : {ROW_GPKG}")

if not os.path.exists(ROW_GPKG):
    logger.error(f"ROW GeoPackage not found: {ROW_GPKG}")
    raise FileNotFoundError(f"ROW GeoPackage not found: {ROW_GPKG}")

logger.info("Reading ROW GeoPackage...")
row = gpd.read_file(ROW_GPKG)
logger.info("ROW GeoPackage loaded successfully.")
logger.info(f"Total ROW polygons  : {len(row):,}")
logger.info(f"Columns             : {list(row.columns)}")
logger.info(f"Geometry type(s)    : {row.geom_type.unique().tolist()}")
logger.info(f"CRS                 : {row.crs}")
logger.info(f"CRS (EPSG)          : EPSG:{row.crs.to_epsg()}")

logger.info("Checking required columns...")
missing = [col for col in ROW_REQUIRED_COLS if col not in row.columns]
if missing:
    logger.error(f"Missing required columns: {missing}")
    logger.error(f"Available columns: {list(row.columns)}")
    raise ValueError(f"Missing required columns in ROW GeoPackage: {missing}")
logger.info(f"All required columns confirmed: {ROW_REQUIRED_COLS}")

logger.info("-" * 40)
logger.info("ROW SUMMARY STATISTICS")
logger.info(f"  Total polygons       : {len(row):,}")
logger.info(f"  Unique states        : {row['State_Name'].nunique()}")
logger.info(f"  States present       : {sorted(row['State_Name'].dropna().unique().tolist())}")
logger.info(f"  Square_Meters min    : {row['Square_Meters'].min():,.2f}")
logger.info(f"  Square_Meters max    : {row['Square_Meters'].max():,.2f}")
logger.info(f"  Square_Meters mean   : {row['Square_Meters'].mean():,.2f}")
logger.info(f"  Polygons >= 2000 sqm : {(row['Square_Meters'] >= 2000).sum():,}")
logger.info(f"  Polygons <  2000 sqm : {(row['Square_Meters'] < 2000).sum():,}")
logger.info("-" * 40)

# ── LOAD TIGER ────────────────────────────────────────────────────────────────
logger.info("=" * 60)
logger.info("LOADING TIGER GEOPACKAGE")
logger.info("=" * 60)
logger.info(f"File path : {TIGER_GPKG}")

if not os.path.exists(TIGER_GPKG):
    logger.error(f"TIGER GeoPackage not found: {TIGER_GPKG}")
    raise FileNotFoundError(f"TIGER GeoPackage not found: {TIGER_GPKG}")

logger.info("Reading TIGER GeoPackage...")
tiger = gpd.read_file(TIGER_GPKG)
logger.info("TIGER GeoPackage loaded successfully.")
logger.info(f"Total road segments : {len(tiger):,}")
logger.info(f"Columns             : {list(tiger.columns)}")
logger.info(f"Geometry type(s)    : {tiger.geom_type.unique().tolist()}")
logger.info(f"CRS                 : {tiger.crs}")
logger.info(f"CRS (EPSG)          : EPSG:{tiger.crs.to_epsg()}")

logger.info("-" * 40)
logger.info("NOTE: No reprojection is performed.")
logger.info("Please confirm both CRS values above match before proceeding.")
logger.info("-" * 40)

# ── COMPLETE ──────────────────────────────────────────────────────────────────
end_time = datetime.now()
elapsed  = end_time - start_time

logger.info("=" * 60)
logger.info("SCRIPT 01 COMPLETE")
logger.info(f"Finished : {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
logger.info(f"Elapsed  : {str(elapsed).split('.')[0]}")
logger.info("Variables available in namespace: row, tiger")
logger.info("=" * 60)
