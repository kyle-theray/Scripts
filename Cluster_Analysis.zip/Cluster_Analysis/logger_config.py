"""
logger_config.py

PURPOSE:
    Shared logger configuration used by all pipeline scripts.
    Writes to both console and a timestamped log file in the logs/ directory.
    Each script run produces its own log file.
"""

import logging
import os
from datetime import datetime


def get_logger(script_name: str, log_dir: str = "logs") -> logging.Logger:
    """
    Creates and returns a logger that writes to both console and a timestamped log file.

    Args:
        script_name : Name of the script using the logger (used in log filename)
        log_dir     : Directory to store log files (created if it does not exist)

    Returns:
        Configured logger instance
    """

    # --- Create log directory if it does not exist ---
    os.makedirs(log_dir, exist_ok=True)

    # --- Generate timestamped log filename ---
    timestamp    = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = os.path.join(log_dir, f"{script_name}_{timestamp}.log")

    # --- Create logger ---
    logger = logging.getLogger(script_name)
    logger.setLevel(logging.DEBUG)

    # --- Avoid duplicate handlers if logger already exists ---
    if logger.handlers:
        logger.handlers.clear()

    # --- Console handler (INFO and above) ---
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_format  = logging.Formatter(
        fmt     = "[%(asctime)s] [%(levelname)s] %(message)s",
        datefmt = "%H:%M:%S"
    )
    console_handler.setFormatter(console_format)

    # --- File handler (DEBUG and above) ---
    file_handler = logging.FileHandler(log_filename, mode="w", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_format  = logging.Formatter(
        fmt     = "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
        datefmt = "%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(file_format)

    # --- Attach handlers ---
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    logger.info(f"Logger initialized for  : {script_name}")
    logger.info(f"Log file                : {log_filename}")

    return logger