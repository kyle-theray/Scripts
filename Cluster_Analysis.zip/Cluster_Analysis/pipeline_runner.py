# ============================================================
# ROW CLUSTER ANALYSIS PIPELINE
# ============================================================
# Run each cell in order. Each %run call executes the
# corresponding .py script and prints all logger output
# directly in the cell output.
#
# BEFORE RUNNING:
#   1. Update ROW_GPKG and TIGER_GPKG paths in 01_prepare_data.py
#   2. Update CURRENT_STATE in 02_build_proximity_graph.py
#   3. Update CURRENT_STATE in 03_cluster_and_export.py
#   4. Confirm all .py files and logger_config.py are in the
#      same directory as this notebook
# ============================================================


# ── CELL 1 ───────────────────────────────────────────────────
# Load ROW and TIGER GeoPackages
# Outputs: row, tiger available in namespace
# -------------------------------------------------------------
%run -i 01_prepare_data.py


# ── CELL 2 ───────────────────────────────────────────────────
# Build proximity graph for current state
# - Clips TIGER to state bounding box
# - Finds candidate pairs within 30m
# - Evaluates pairs using multiprocessing (80% cores)
# - Saves graph pickle to proximity_graphs/
# Outputs: graph, row_state available in namespace
# -------------------------------------------------------------
%run -i 02_build_proximity_graph.py


# ── CELL 3 ───────────────────────────────────────────────────
# Cluster and export for current state
# - Extracts connected components
# - Validates 2000 sqm rule
# - Assigns Cluster_IDs
# - Exports per-state CSV to state_outputs/
# -------------------------------------------------------------
%run -i 03_cluster_and_export.py


# ── CELL 4 ───────────────────────────────────────────────────
# Merge all state CSVs into final CONUS CSV
# - Run this only after all states are complete
# - Reassigns globally unique Cluster_IDs
# - Validates row counts
# - Exports final_output/CONUS_clusters.csv
# -------------------------------------------------------------
%run -i 04_merge_results.py


# ============================================================
# RECOVERY INSTRUCTIONS
# ============================================================
# If Cell 2 fails:
#   Fix the issue and rerun Cell 2 only
#
# If Cell 3 fails:
#   Fix the issue and rerun Cell 3 only
#   Script 03 will load the graph from the pickle automatically
#   No need to rerun Cell 2
#
# If you need to rerun a state from scratch:
#   Delete the pickle from proximity_graphs/{state}_graph.pkl
#   Then rerun Cell 2 and Cell 3
#
# To run a new state:
#   Update CURRENT_STATE in 02_build_proximity_graph.py
#   Update CURRENT_STATE in 03_cluster_and_export.py
#   Rerun Cell 2 and Cell 3
#   Run Cell 4 only when all states are complete
# ============================================================
