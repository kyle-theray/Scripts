"""
02_build_proximity_graph.py

PURPOSE:
    Loops through every unique State_Name in the ROW dataset and for each state:
      1. Clips TIGER roads to a buffered bounding box around the state ROW
      2. Builds STRtree spatial indexes over ROW polygons and TIGER lines
      3. Finds candidate polygon pairs within 30m bounding box envelope
      4. Evaluates each candidate pair single-threaded:
             a. True perimeter-to-perimeter distance via Shapely .distance()
             b. Shortest line TIGER intersection check via shortest_line()
      5. Builds NetworkX proximity graph from valid edges
      6. Saves graph as pickle for recovery
      7. Skips state if pickle already exists

INPUTS (from namespace):
    - row   : Full ROW GeoDataFrame (from Script 01)
    - tiger : TIGER GeoDataFrame (from Script 01)

OUTPUTS:
    - proximity_graphs/{state}_graph.pkl : Graph pickle per state saved to disk
    - graph     : NetworkX graph saved to namespace (last state processed)
    - row_state : State-subset ROW GeoDataFrame saved to namespace (last state processed)

NOTES:
    - All distances in meters (EPSG:5070)
    - Single-threaded for stability — STRtree handles the heavy lifting
    - Skips states whose pickle already exists for pipeline resumability
"""

import os
import sys
import pickle
from datetime import datetime

import geopandas as gpd
import networkx as nx
import shapely
from shapely.strtree import STRtree
from shapely.geometry import box

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from logger_config import get_logger

# ── CONFIGURATION ─────────────────────────────────────────────────────────────
PROXIMITY_DIR      = "proximity_graphs"
DISTANCE_THRESHOLD = 30.0    # meters
TIGER_CLIP_BUFFER  = 500.0   # meters — buffer around state bbox for TIGER clip
# ─────────────────────────────────────────────────────────────────────────────


def clip_tiger_to_state(tiger, row_state, state, logger):
    """Clip TIGER lines to buffered bounding box of state ROW polygons."""
    logger.info(f"[{state}] Clipping TIGER to state bounding box...")
    minx, miny, maxx, maxy = row_state.total_bounds
    state_bbox = box(
        minx - TIGER_CLIP_BUFFER,
        miny - TIGER_CLIP_BUFFER,
        maxx + TIGER_CLIP_BUFFER,
        maxy + TIGER_CLIP_BUFFER
    )
    logger.info(f"[{state}]   Bounding box (buffered {TIGER_CLIP_BUFFER}m):")
    logger.info(f"[{state}]   minx={minx:.2f}, miny={miny:.2f}, maxx={maxx:.2f}, maxy={maxy:.2f}")
    logger.info(f"[{state}]   TIGER segments before clip : {len(tiger):,}")
    tiger_clipped = tiger[tiger.geometry.intersects(state_bbox)].copy()
    logger.info(f"[{state}]   TIGER segments after clip  : {len(tiger_clipped):,}")
    logger.info(f"[{state}]   TIGER segments removed     : {len(tiger) - len(tiger_clipped):,}")
    return tiger_clipped.geometry.values.tolist()


def build_candidate_pairs(row_geoms, state, logger):
    """Find candidate pairs within DISTANCE_THRESHOLD envelope using STRtree."""
    logger.info(f"[{state}] Building ROW spatial index...")
    row_index = STRtree(row_geoms)
    logger.info(f"[{state}] ROW spatial index built. ({len(row_geoms):,} polygons indexed)")
    logger.info(f"[{state}] Finding candidate pairs within {DISTANCE_THRESHOLD}m envelope...")

    candidate_pairs = set()
    for i, geom in enumerate(row_geoms):
        expanded_bbox = box(
            geom.bounds[0] - DISTANCE_THRESHOLD,
            geom.bounds[1] - DISTANCE_THRESHOLD,
            geom.bounds[2] + DISTANCE_THRESHOLD,
            geom.bounds[3] + DISTANCE_THRESHOLD
        )
        nearby = row_index.query(expanded_bbox)
        for j in nearby:
            if j <= i:
                continue
            candidate_pairs.add((i, j))

        if i % 5000 == 0 and i > 0:
            logger.info(f"[{state}]   Index query progress: {i:,} / {len(row_geoms):,} polygons | Pairs so far: {len(candidate_pairs):,}")

    candidate_pairs = list(candidate_pairs)
    logger.info(f"[{state}] Candidate pairs found: {len(candidate_pairs):,}")
    return candidate_pairs


def evaluate_pairs(candidate_pairs, row_geoms, tiger_geoms, state, logger):
    """
    Evaluate all candidate pairs single-threaded.
    For each pair:
        1. True perimeter-to-perimeter distance via .distance()
        2. Shortest line TIGER intersection check via shortest_line()
    Returns list of valid (i, j, distance) edge tuples.
    """
    logger.info(f"[{state}] Evaluating {len(candidate_pairs):,} candidate pairs...")

    tiger_index = STRtree(tiger_geoms)
    valid_edges   = []
    too_far       = 0
    blocked       = 0
    log_interval  = max(1, len(candidate_pairs) // 10)

    for count, (i, j) in enumerate(candidate_pairs):
        geom_i = row_geoms[i]
        geom_j = row_geoms[j]

        # --- True perimeter-to-perimeter distance ---
        dist = geom_i.distance(geom_j)
        if dist > DISTANCE_THRESHOLD:
            too_far += 1
            continue

        # --- Shortest line between polygons ---
        shortest_line = shapely.shortest_line(geom_i, geom_j)

        # --- Check if shortest line crosses any TIGER road ---
        candidate_tiger = tiger_index.query(shortest_line)
        is_blocked = any(
            shortest_line.crosses(tiger_geoms[k]) or shortest_line.intersects(tiger_geoms[k])
            for k in candidate_tiger
        )

        if is_blocked:
            blocked += 1
            continue

        valid_edges.append((i, j, dist))

        # --- Progress logging every ~10% ---
        if count % log_interval == 0 and count > 0:
            pct = (count / len(candidate_pairs)) * 100
            logger.info(
                f"[{state}]   Pair evaluation progress : {count:,} / {len(candidate_pairs):,} ({pct:.0f}%) | "
                f"Valid: {len(valid_edges):,} | Too far: {too_far:,} | Blocked: {blocked:,}"
            )

    logger.info(f"[{state}] Pair evaluation complete.")
    logger.info(f"[{state}]   Valid edges            : {len(valid_edges):,}")
    logger.info(f"[{state}]   Rejected (too far)     : {too_far:,}")
    logger.info(f"[{state}]   Rejected (road blocked): {blocked:,}")

    return valid_edges


def process_state(state, row, tiger, logger):
    """
    Run the full proximity graph build for a single state.
    Returns (graph, row_state) tuple or (None, None) if skipped.
    """
    logger.info(f"[{state}] ---- BEGIN STATE PROCESSING ----")

    # --- Subset ROW to this state ---
    row_state = row[row["State_Name"] == state].copy().reset_index(drop=True)
    logger.info(f"[{state}] ROW polygons for this state: {len(row_state):,}")

    if len(row_state) == 0:
        logger.warning(f"[{state}] No ROW polygons found. Skipping.")
        return None, None

    # --- Extract geometries ---
    logger.info(f"[{state}] Extracting ROW geometries...")
    row_geoms = row_state.geometry.values.tolist()
    logger.info(f"[{state}] ROW geometries extracted: {len(row_geoms):,}")

    # --- Clip TIGER to state ---
    tiger_geoms = clip_tiger_to_state(tiger, row_state, state, logger)

    # --- Build candidate pairs ---
    candidate_pairs = build_candidate_pairs(row_geoms, state, logger)

    # --- Evaluate pairs and build graph ---
    if len(candidate_pairs) == 0:
        logger.warning(f"[{state}] No candidate pairs found within {DISTANCE_THRESHOLD}m. Graph will have no edges.")
        graph = nx.Graph()
        graph.add_nodes_from(range(len(row_state)))
    else:
        valid_edges = evaluate_pairs(candidate_pairs, row_geoms, tiger_geoms, state, logger)

        logger.info(f"[{state}] Building NetworkX graph...")
        graph = nx.Graph()
        graph.add_nodes_from(range(len(row_state)))
        for i, j, dist in valid_edges:
            graph.add_edge(i, j, distance=dist)

    logger.info(f"[{state}] ---- GRAPH SUMMARY ----")
    logger.info(f"[{state}]   Nodes : {graph.number_of_nodes():,}")
    logger.info(f"[{state}]   Edges : {graph.number_of_edges():,}")

    # --- Save graph pickle ---
    os.makedirs(PROXIMITY_DIR, exist_ok=True)
    state_slug  = state.replace(" ", "_")
    pickle_path = os.path.join(PROXIMITY_DIR, f"{state_slug}_graph.pkl")

    logger.info(f"[{state}] Saving graph pickle to: {pickle_path}")
    with open(pickle_path, "wb") as f:
        pickle.dump(graph, f)
    logger.info(f"[{state}] Graph pickle saved successfully.")

    return graph, row_state


# ── MAIN EXECUTION ────────────────────────────────────────────────────────────
logger     = get_logger("02_build_proximity_graph")
start_time = datetime.now()

logger.info("=" * 60)
logger.info("SCRIPT 02 - BUILD PROXIMITY GRAPH")
logger.info(f"Started : {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
logger.info("=" * 60)

os.makedirs(PROXIMITY_DIR, exist_ok=True)

# --- Get all unique states ---
states = sorted(row["State_Name"].dropna().unique().tolist())
logger.info(f"Total states to process: {len(states)}")
logger.info(f"States: {states}")

# --- Track results ---
results = {"success": [], "failed": [], "skipped": []}

# --- State loop ---
logger.info("=" * 60)
logger.info("BEGINNING STATE LOOP")
logger.info("=" * 60)

for i, state in enumerate(states, start=1):
    state_start = datetime.now()
    logger.info(f"\n[{i} / {len(states)}] Processing: {state}")

    # --- Check if pickle already exists ---
    state_slug  = state.replace(" ", "_")
    pickle_path = os.path.join(PROXIMITY_DIR, f"{state_slug}_graph.pkl")

    if os.path.exists(pickle_path):
        logger.info(f"[{state}] Pickle already exists. Skipping: {pickle_path}")
        results["skipped"].append(state)
        continue

    # --- Process state ---
    try:
        graph, row_state = process_state(state, row, tiger, logger)
        state_elapsed    = datetime.now() - state_start

        if graph is not None:
            results["success"].append(state)
            logger.info(f"[{state}] Completed in {str(state_elapsed).split('.')[0]}")
        else:
            results["skipped"].append(state)

    except Exception as e:
        state_elapsed = datetime.now() - state_start
        logger.error(f"[{state}] Failed after {str(state_elapsed).split('.')[0]}: {e}", exc_info=True)
        results["failed"].append(state)

# ── FINAL SUMMARY ─────────────────────────────────────────────────────────────
end_time = datetime.now()
elapsed  = end_time - start_time

logger.info("=" * 60)
logger.info("SCRIPT 02 COMPLETE — FINAL SUMMARY")
logger.info(f"Finished   : {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
logger.info(f"Elapsed    : {str(elapsed).split('.')[0]}")
logger.info(f"Successful : {len(results['success'])} — {results['success']}")
logger.info(f"Failed     : {len(results['failed'])} — {results['failed']}")
logger.info(f"Skipped    : {len(results['skipped'])} — {results['skipped']}")
logger.info("=" * 60)

if results["failed"]:
    logger.warning("Some states failed. Review logs above for details.")
    logger.warning("Rerun this script to retry — successful states will be skipped automatically.")