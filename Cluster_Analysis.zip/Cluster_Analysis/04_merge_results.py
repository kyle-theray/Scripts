"""
04_merge_results.py

PURPOSE:
    Merge all per-state cluster CSVs into a single CONUS-wide CSV.
    Reassigns Cluster_IDs to be globally unique across all states.
    Validates row counts after merge to confirm no silent data loss.

INPUTS:
    - state_outputs/{state}_clusters.csv (one per state from Script 03)

OUTPUTS:
    - final_output/CONUS_clusters.csv

NOTES:
    - Checks which state CSVs exist before merging
    - Logs any states that are missing a CSV
    - Per-state Cluster_IDs are reassigned to globally unique integers
    - Null Cluster_IDs remain null in the final output
    - State_Name column added for traceability
    - Row count validated after merge to confirm no data loss
"""

import os
import sys
import glob
import pandas as pd
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from logger_config import get_logger

# ── USER CONFIGURATION ────────────────────────────────────────────────────────
STATE_OUTPUT_DIR = "state_outputs"
FINAL_OUTPUT_DIR = "final_output"
FINAL_FILENAME   = "CONUS_clusters.csv"
# ─────────────────────────────────────────────────────────────────────────────

logger     = get_logger("04_merge_results")
start_time = datetime.now()

logger.info("=" * 60)
logger.info("SCRIPT 04 - MERGE RESULTS")
logger.info(f"Started : {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
logger.info("=" * 60)

# ── FIND STATE CSVs ───────────────────────────────────────────────────────────
logger.info(f"Searching for state CSVs in: {os.path.abspath(STATE_OUTPUT_DIR)}")
pattern   = os.path.join(STATE_OUTPUT_DIR, "*_clusters.csv")
csv_files = sorted(glob.glob(pattern))

if not csv_files:
    logger.error(f"No state CSV files found in: {STATE_OUTPUT_DIR}")
    logger.error("Please run 03_cluster_and_export.py for each state first.")
    raise FileNotFoundError(f"No state CSV files found in: {STATE_OUTPUT_DIR}")

logger.info(f"Found {len(csv_files)} state CSV files:")
for f in csv_files:
    logger.info(f"  {os.path.basename(f)}")

# ── LOAD AND CONCATENATE ──────────────────────────────────────────────────────
logger.info("=" * 60)
logger.info("LOADING AND CONCATENATING STATE CSVs")
logger.info("=" * 60)

dfs               = []
expected_total    = 0
total_clustered   = 0
total_unclustered = 0

for csv_path in csv_files:
    filename   = os.path.basename(csv_path)
    state_name = filename.replace("_clusters.csv", "").replace("_", " ")

    logger.info(f"Loading: {filename}")
    df = pd.read_csv(csv_path, dtype={"Cluster_ID": pd.Int64Dtype()})
    df["State_Name"] = state_name

    clustered    = df["Cluster_ID"].notna().sum()
    unclustered  = df["Cluster_ID"].isna().sum()
    num_clusters = df["Cluster_ID"].nunique(dropna=True)

    logger.info(f"  [{state_name}] Rows: {len(df):,} | Clustered: {clustered:,} | Unclustered: {unclustered:,} | Clusters: {num_clusters:,}")

    expected_total    += len(df)
    total_clustered   += clustered
    total_unclustered += unclustered
    dfs.append(df)

combined = pd.concat(dfs, ignore_index=True)

logger.info("-" * 40)
logger.info(f"Expected total rows (sum of state CSVs) : {expected_total:,}")
logger.info(f"Actual rows in combined DataFrame       : {len(combined):,}")
logger.info(f"Total clustered polygons                : {total_clustered:,}")
logger.info(f"Total unclustered polygons              : {total_unclustered:,}")
logger.info("-" * 40)

# ── VALIDATE ROW COUNT ────────────────────────────────────────────────────────
logger.info("Validating row count after merge...")
if len(combined) != expected_total:
    logger.error(f"ROW COUNT MISMATCH DETECTED.")
    logger.error(f"  Expected   : {expected_total:,}")
    logger.error(f"  Actual     : {len(combined):,}")
    logger.error(f"  Difference : {abs(len(combined) - expected_total):,} rows")
    raise ValueError(f"Row count mismatch: expected {expected_total:,}, got {len(combined):,}")
logger.info(f"Row count validation passed. Total rows: {len(combined):,}")

# ── REASSIGN GLOBAL CLUSTER IDs ───────────────────────────────────────────────
logger.info("=" * 60)
logger.info("REASSIGNING GLOBALLY UNIQUE CLUSTER IDs")
logger.info("=" * 60)

combined["Cluster_ID_Global"] = pd.array([pd.NA] * len(combined), dtype=pd.Int64Dtype())
global_offset = 0
states        = sorted(combined["State_Name"].unique().tolist())

logger.info(f"Reassigning IDs across {len(states)} states...")

for state in states:
    mask           = (combined["State_Name"] == state) & (combined["Cluster_ID"].notna())
    state_clusters = combined.loc[mask, "Cluster_ID"]

    if state_clusters.empty:
        logger.info(f"  [{state}] No clustered polygons. Skipping.")
        continue

    local_ids   = state_clusters.astype(int)
    local_max   = int(local_ids.max())
    local_count = int(local_ids.nunique())

    combined.loc[mask, "Cluster_ID_Global"] = local_ids + global_offset

    logger.info(
        f"  [{state}] Local IDs 1-{local_max} ({local_count} clusters) "
        f"-> Global IDs {global_offset + 1}-{global_offset + local_max}"
    )

    global_offset += local_max

combined["Cluster_ID"] = combined["Cluster_ID_Global"]
combined = combined.drop(columns=["Cluster_ID_Global"])

total_global = int(combined["Cluster_ID"].nunique(dropna=True))
global_max   = int(combined["Cluster_ID"].max(skipna=True))

logger.info(f"Total global clusters : {total_global:,}")
logger.info(f"Global ID range       : 1 to {global_max:,}")

# ── EXPORT FINAL CSV ──────────────────────────────────────────────────────────
logger.info("=" * 60)
logger.info("EXPORTING FINAL CONUS CSV")
logger.info("=" * 60)

os.makedirs(FINAL_OUTPUT_DIR, exist_ok=True)
output_path = os.path.join(FINAL_OUTPUT_DIR, FINAL_FILENAME)

combined = combined[["ROW_ID", "Square_Meters", "Cluster_ID", "State_Name"]]
combined.to_csv(output_path, index=False)

logger.info(f"Output path    : {os.path.abspath(output_path)}")
logger.info(f"Total rows     : {len(combined):,}")
logger.info(f"Columns        : {list(combined.columns)}")
logger.info(f"Clustered      : {combined['Cluster_ID'].notna().sum():,}")
logger.info(f"Unclustered    : {combined['Cluster_ID'].isna().sum():,}")
logger.info(f"Total clusters : {combined['Cluster_ID'].nunique(dropna=True):,}")
logger.info("Final CONUS CSV exported successfully.")

# ── COMPLETE ──────────────────────────────────────────────────────────────────
end_time = datetime.now()
elapsed  = end_time - start_time

logger.info("=" * 60)
logger.info("SCRIPT 04 COMPLETE")
logger.info(f"Finished : {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
logger.info(f"Elapsed  : {str(elapsed).split('.')[0]}")
logger.info(f"Output   : {os.path.abspath(output_path)}")
logger.info("=" * 60)
