"""
03_cluster_and_export.py

PURPOSE:
    Loops through every unique State_Name in the ROW dataset and for each state:
      1. Loads the graph pickle saved by Script 02
      2. Extracts connected components from the proximity graph
      3. Validates each component — at least one polygon must have
         Square_Meters >= 2000 for the cluster to be valid
      4. Assigns sequential numeric Cluster_IDs to valid clusters
      5. Exports per-state CSV with ROW_ID, Square_Meters, Cluster_ID
      6. Skips state if per-state CSV already exists

INPUTS (from namespace):
    - row : Full ROW GeoDataFrame (from Script 01)

OUTPUTS:
    - state_outputs/{state}_clusters.csv per state

NOTES:
    - Cluster_ID uses pd.Int64Dtype() so nulls write as empty in CSV
    - All polygons in a valid component receive the same Cluster_ID
    - Polygons not in a valid cluster receive null Cluster_ID
    - Skips states whose CSV already exists for pipeline resumability
    - Logs a warning for any state whose pickle is missing
"""

import os
import sys
import pickle
import geopandas as gpd
import pandas as pd
import networkx as nx
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from logger_config import get_logger

# ── CONFIGURATION ─────────────────────────────────────────────────────────────
PROXIMITY_DIR    = "proximity_graphs"
STATE_OUTPUT_DIR = "state_outputs"

MIN_AREA_SQM = 2000.0
AREA_COLUMN  = "Square_Meters"
ID_COLUMN    = "ROW_ID"
# ─────────────────────────────────────────────────────────────────────────────


def process_state(state, row, logger):
    """
    Run the full cluster and export pipeline for a single state.
    Returns output CSV path if successful, None if skipped or failed.
    """
    state_slug  = state.replace(" ", "_")
    pickle_path = os.path.join(PROXIMITY_DIR, f"{state_slug}_graph.pkl")
    output_path = os.path.join(STATE_OUTPUT_DIR, f"{state_slug}_clusters.csv")

    # --- Load graph pickle ---
    if not os.path.exists(pickle_path):
        logger.warning(f"[{state}] Graph pickle not found: {pickle_path}")
        logger.warning(f"[{state}] Please run 02_build_proximity_graph.py for this state first.")
        return None

    logger.info(f"[{state}] Loading graph pickle: {pickle_path}")
    with open(pickle_path, "rb") as f:
        graph = pickle.load(f)
    logger.info(f"[{state}]   Nodes : {graph.number_of_nodes():,}")
    logger.info(f"[{state}]   Edges : {graph.number_of_edges():,}")

    # --- Subset ROW to this state ---
    logger.info(f"[{state}] Subsetting ROW to state...")
    row_state = row[row["State_Name"] == state].copy().reset_index(drop=True)
    logger.info(f"[{state}] ROW polygons for this state: {len(row_state):,}")

    if len(row_state) == 0:
        logger.warning(f"[{state}] No ROW polygons found. Skipping.")
        return None

    # --- Extract connected components ---
    logger.info(f"[{state}] Extracting connected components...")
    all_components   = list(nx.connected_components(graph))
    singletons       = [c for c in all_components if len(c) == 1]
    multi_components = [c for c in all_components if len(c) > 1]

    logger.info(f"[{state}] ---- CONNECTED COMPONENTS ----")
    logger.info(f"[{state}]   Total components                    : {len(all_components):,}")
    logger.info(f"[{state}]   Single-polygon (isolated, no edges) : {len(singletons):,}")
    logger.info(f"[{state}]   Multi-polygon (candidate clusters)  : {len(multi_components):,}")

    # --- Validate components against area rule ---
    logger.info(f"[{state}] Validating candidate clusters...")
    logger.info(f"[{state}] Rule: at least 1 polygon must have {AREA_COLUMN} >= {MIN_AREA_SQM}")

    valid_components   = []
    invalid_components = []

    for component in multi_components:
        node_indices = list(component)
        areas        = row_state.loc[node_indices, AREA_COLUMN].values
        qualifies    = any(a >= MIN_AREA_SQM for a in areas)
        if qualifies:
            valid_components.append(component)
        else:
            invalid_components.append(component)

    logger.info(f"[{state}]   Valid clusters   : {len(valid_components):,}")
    logger.info(f"[{state}]   Invalid clusters : {len(invalid_components):,}")

    if valid_components:
        sizes = sorted([len(c) for c in valid_components], reverse=True)
        logger.info(f"[{state}] Valid cluster size stats:")
        logger.info(f"[{state}]   Largest cluster            : {sizes[0]:,} polygons")
        logger.info(f"[{state}]   Smallest cluster           : {sizes[-1]:,} polygons")
        logger.info(f"[{state}]   Mean cluster size          : {sum(sizes)/len(sizes):.1f} polygons")
        logger.info(f"[{state}]   Total polygons in clusters : {sum(sizes):,}")

    # --- Assign Cluster_IDs ---
    logger.info(f"[{state}] Assigning Cluster_IDs...")
    result = row_state[[ID_COLUMN, AREA_COLUMN]].copy()
    result["Cluster_ID"] = pd.array([pd.NA] * len(result), dtype=pd.Int64Dtype())

    cluster_id = 1
    for component in valid_components:
        node_indices = list(component)
        result.loc[node_indices, "Cluster_ID"] = cluster_id
        cluster_id += 1

    total_clusters = cluster_id - 1
    assigned       = result["Cluster_ID"].notna().sum()
    unassigned     = result["Cluster_ID"].isna().sum()

    logger.info(f"[{state}] ---- CLUSTER ID ASSIGNMENT ----")
    logger.info(f"[{state}]   Total valid clusters assigned         : {total_clusters:,}")
    logger.info(f"[{state}]   Polygons assigned a Cluster_ID        : {assigned:,}")
    logger.info(f"[{state}]   Polygons with null Cluster_ID         : {unassigned:,}")
    logger.info(f"[{state}]     -> Isolated (no neighbors)          : {len(singletons):,}")
    logger.info(f"[{state}]     -> In invalid clusters (no 2000sqm) : {sum(len(c) for c in invalid_components):,}")

    # --- Export CSV ---
    os.makedirs(STATE_OUTPUT_DIR, exist_ok=True)
    result = result[[ID_COLUMN, AREA_COLUMN, "Cluster_ID"]]
    result.to_csv(output_path, index=False)

    logger.info(f"[{state}] CSV exported to: {os.path.abspath(output_path)}")
    logger.info(f"[{state}] Total rows : {len(result):,}")
    logger.info(f"[{state}] CSV preview (first 5 rows):")
    for _, row_preview in result.head(5).iterrows():
        logger.info(f"[{state}]   {row_preview.to_dict()}")

    return output_path


# ── MAIN EXECUTION ────────────────────────────────────────────────────────────
logger     = get_logger("03_cluster_and_export")
start_time = datetime.now()

logger.info("=" * 60)
logger.info("SCRIPT 03 - CLUSTER AND EXPORT")
logger.info(f"Started : {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
logger.info("=" * 60)

os.makedirs(STATE_OUTPUT_DIR, exist_ok=True)

# --- Get all unique states ---
states = sorted(row["State_Name"].dropna().unique().tolist())
logger.info(f"Total states to process: {len(states)}")
logger.info(f"States: {states}")

# --- Track results ---
results = {"success": [], "failed": [], "skipped": []}

# --- State loop ---
logger.info("=" * 60)
logger.info("BEGINNING STATE LOOP")
logger.info("=" * 60)

for i, state in enumerate(states, start=1):
    state_start = datetime.now()
    logger.info(f"\n[{i} / {len(states)}] Processing: {state}")

    # --- Check if CSV already exists ---
    state_slug  = state.replace(" ", "_")
    output_path = os.path.join(STATE_OUTPUT_DIR, f"{state_slug}_clusters.csv")

    if os.path.exists(output_path):
        logger.info(f"[{state}] CSV already exists. Skipping: {output_path}")
        results["skipped"].append(state)
        continue

    # --- Process state ---
    try:
        result_path   = process_state(state, row, logger)
        state_elapsed = datetime.now() - state_start

        if result_path is not None:
            results["success"].append(state)
            logger.info(f"[{state}] Completed in {str(state_elapsed).split('.')[0]}")
        else:
            results["skipped"].append(state)

    except Exception as e:
        state_elapsed = datetime.now() - state_start
        logger.error(f"[{state}] Failed after {str(state_elapsed).split('.')[0]}: {e}", exc_info=True)
        results["failed"].append(state)

# ── FINAL SUMMARY ─────────────────────────────────────────────────────────────
end_time = datetime.now()
elapsed  = end_time - start_time

logger.info("=" * 60)
logger.info("SCRIPT 03 COMPLETE — FINAL SUMMARY")
logger.info(f"Finished   : {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
logger.info(f"Elapsed    : {str(elapsed).split('.')[0]}")
logger.info(f"Successful : {len(results['success'])} — {results['success']}")
logger.info(f"Failed     : {len(results['failed'])} — {results['failed']}")
logger.info(f"Skipped    : {len(results['skipped'])} — {results['skipped']}")
logger.info("=" * 60)

if results["failed"]:
    logger.warning("Some states failed. Review logs above for details.")
    logger.warning("Rerun this script to retry failed states — successful states will be skipped automatically.")